import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class BusReservationSystemGUI {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mini";
    private static final String USER = "root";
    private static final String PASSWORD = "mysql@123";

    private JFrame frame;
    private JTextField busNumberField;
    private JTextField nameField;
    private JTextField ageField;
    private JTextField genderField;
    private JTextField aadharCardField;
    private JTextField destinationField;
    private JCheckBox sleeperCheckBox;
    private JCheckBox acCheckBox;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                BusReservationSystemGUI window = new BusReservationSystemGUI();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public BusReservationSystemGUI() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Bus Reservation System");
        frame.setBounds(100, 100, 500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.getContentPane().add(panel, BorderLayout.CENTER);
        panel.setLayout(new GridLayout(0, 2, 10, 10));

        JLabel busNumberLabel = new JLabel("Bus Number:");
        busNumberField = new JTextField();
        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();
        JLabel ageLabel = new JLabel("Age:");
        ageField = new JTextField();
        JLabel genderLabel = new JLabel("Gender:");
        genderField = new JTextField();
        JLabel aadharCardLabel = new JLabel("Aadhar Card:");
        aadharCardField = new JTextField();
        JLabel destinationLabel = new JLabel("Destination:");
        destinationField = new JTextField();
        sleeperCheckBox = new JCheckBox("Sleeper");
        acCheckBox = new JCheckBox("AC");

        JButton reserveButton = new JButton("Reserve Seat");
        JButton viewButton = new JButton("View Available Seats");

        panel.add(busNumberLabel);
        panel.add(busNumberField);
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(ageLabel);
        panel.add(ageField);
        panel.add(genderLabel);
        panel.add(genderField);
        panel.add(aadharCardLabel);
        panel.add(aadharCardField);
        panel.add(destinationLabel);
        panel.add(destinationField);
        panel.add(sleeperCheckBox);
        panel.add(acCheckBox);
        panel.add(reserveButton);
        panel.add(viewButton);

        reserveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                reserveSeat();
            }
        });

        viewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewAvailableSeats();
            }
        });
    }

    private void reserveSeat() {
        String busNumber = busNumberField.getText();
        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());
        String gender = genderField.getText();
        String aadharCard = aadharCardField.getText();
        String destination = destinationField.getText();
        boolean isSleeper = sleeperCheckBox.isSelected();
        boolean isAC = acCheckBox.isSelected();

        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "UPDATE bus SET available_seats = available_seats - 1 WHERE bus_number = ? AND available_seats > 0")) {

            preparedStatement.setString(1, busNumber);
            int updatedRows = preparedStatement.executeUpdate();

            if (updatedRows > 0) {
                JOptionPane.showMessageDialog(frame, "Seat reserved successfully!");
                savePassengerDetails(name, age, gender, aadharCard, busNumber, destination, isSleeper, isAC);
            } else {
                JOptionPane.showMessageDialog(frame, "Sorry, no available seats on this bus.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error occurred while reserving seat.");
        }
    }

    private void savePassengerDetails(String name, int age, String gender, String aadharCard, String busNumber, String destination, boolean isSleeper, boolean isAC) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO passenger (name, age, gender, aadhar_card_number, bus_number, destination, is_sleeper, is_ac) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {

            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.setString(3, gender);
            preparedStatement.setString(4, aadharCard);
            preparedStatement.setString(5, busNumber);
            preparedStatement.setString(6, destination);
            preparedStatement.setBoolean(7, isSleeper);
            preparedStatement.setBoolean(8, isAC);

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error occurred while saving passenger details.");
        }
    }

    private void viewAvailableSeats() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
             Statement statement = connection.createStatement()) {

            ResultSet resultSet = statement.executeQuery("SELECT bus_number, destination, sleeper, ac, available_seats FROM bus");

            StringBuilder result = new StringBuilder("\nAvailable Seats:\n");
            result.append("Bus Number\tDestination\tSleeper\tA/C\tAvailable Seats\n");

            while (resultSet.next()) {
                String busNumber = resultSet.getString("bus_number");
                String destination = resultSet.getString("destination");
                boolean isSleeper = resultSet.getBoolean("sleeper");
                boolean isAC = resultSet.getBoolean("ac");
                int availableSeats = resultSet.getInt("available_seats");

                result.append(busNumber).append("\t\t").append(destination).append("\t\t").append(isSleeper)
                        .append("\t").append(isAC).append("\t\t").append(availableSeats).append("\n");
            }

            JTextArea textArea = new JTextArea(result.toString());
            JScrollPane scrollPane = new JScrollPane(textArea);
            JOptionPane.showMessageDialog(frame, scrollPane, "Available Seats", JOptionPane.PLAIN_MESSAGE);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error occurred while fetching available seats.");
        }
    }
}