import java.sql.*;
import java.util.Scanner;

public class BusReservationSystem {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mini";
    private static final String USER = "root";
    private static final String PASSWORD = "mysql@123";
    public static void main(String[] args) {
       
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return;
        }

        createTable();

     Scanner scanner = new Scanner(System.in);

    while (true) {
    System.out.println("\n1. Reserve a seat");
    System.out.println("2. View available seats");
    System.out.println("3. Exit");

    System.out.print("Enter your choice: ");
       // if (scanner.hasNextInt()) {
    int choice = scanner.nextInt();
      //  scanner.nextLine(); 

        switch (choice) {
            case 1:
                reserveSeat();
                break;
            case 2:
                viewAvailableSeats();
                break;
            case 3:
                System.out.println("Exiting the program.");
                scanner.close();
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
        }
}}
 




private static void createTable() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
             Statement statement = connection.createStatement()) {

            String createTableQuery = "CREATE TABLE IF NOT EXISTS bus ("
                    + "id INT PRIMARY KEY AUTO_INCREMENT,"
                    + "bus_number VARCHAR(255),"
                    + "destination VARCHAR(255),"
                    + "sleeper BOOLEAN,"
                    + "ac BOOLEAN,"
                    + "total_seats INT,"
                    + "available_seats INT)";
            statement.executeUpdate(createTableQuery);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void reserveSeat() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "UPDATE bus SET available_seats = available_seats - 1 WHERE bus_number = ? AND available_seats > 0");
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter bus number: ");
            String busNumber = scanner.next();

            System.out.print("Enter your name: ");
            String name = scanner.next();

            System.out.print("Enter your age: ");
            int age = scanner.nextInt();

            System.out.print("Enter your gender: ");
            String gender = scanner.next();

            System.out.print("Enter your Aadhar card number: ");
            String aadharCardNumber = scanner.next();

            System.out.print("Enter destination: ");
            String destination = scanner.next();

            System.out.print("Is it a Sleeper bus? (true/false): ");
            boolean isSleeper = scanner.nextBoolean();

            System.out.print("Is it an A/C bus? (true/false): ");
            boolean isAC = scanner.nextBoolean();

            preparedStatement.setString(1, busNumber);
            int updatedRows = preparedStatement.executeUpdate();

            if (updatedRows > 0) {
                System.out.println("Seat reserved successfully!");
                savePassengerDetails(name, age, gender, aadharCardNumber, busNumber, destination, isSleeper, isAC);
            } else {
                System.out.println("Sorry, no available seats on this bus.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void savePassengerDetails(String name, int age, String gender, String aadharCardNumber, String busNumber, String destination, boolean isSleeper, boolean isAC) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO passenger (name, age, gender, aadhar_card_number, bus_number, destination, is_sleeper, is_ac) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {

            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.setString(3, gender);
            preparedStatement.setString(4, aadharCardNumber);
            preparedStatement.setString(5, busNumber);
            preparedStatement.setString(6, destination);
            preparedStatement.setBoolean(7, isSleeper);
            preparedStatement.setBoolean(8, isAC);

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAvailableSeats() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
             Statement statement = connection.createStatement()) {

            ResultSet resultSet = statement.executeQuery("SELECT bus_number, destination, sleeper, ac, available_seats FROM bus");

            System.out.println("\nAvailable Seats:");
            System.out.println("Bus Number\tDestination\t\t\tSleeper\tA/C\tAvailable Seats");
            while (resultSet.next()) {
                String busNumber = resultSet.getString("bus_number");
                String destination = resultSet.getString("destination");
                boolean isSleeper = resultSet.getBoolean("sleeper");
                boolean isAC = resultSet.getBoolean("ac");
                int availableSeats = resultSet.getInt("available_seats");
                System.out.println(busNumber + "\t\t" + destination + "\t\t" + isSleeper + "\t" + isAC + "\t\t" + availableSeats);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
