const express = require("express");
const cors = require("cors");
const { getDatabase, ref, get } = require("firebase/database");
const { initializeApp } = require("firebase/app");

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCY1lPG5uRnt2bw3wdrg7eGjz3mkoAw1lU",
  authDomain: "product-expiry-management.firebaseapp.com",
  databaseURL: "https://product-expiry-management-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "product-expiry-management",
  storageBucket: "product-expiry-management.appspot.com",
  messagingSenderId: "453668811856",
  appId: "1:453668811856:web:e9b1713218d616bc428d55",
  measurementId: "G-GVMBN8DDBJ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

const server = express();
server.use(cors());
server.use(express.json());

// Route to fetch products
server.get("/api/products", async (req, res) => {
  try {
    const productsRef = ref(database, "qr_codes");
    const snapshot = await get(productsRef);

    if (!snapshot.exists()) {
      return res.status(404).json({ message: "No products found" });
    }

    const products = Object.keys(snapshot.val()).map((key) => ({
      id: key,
      ...snapshot.val()[key],
    }));

    res.json(products);
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
