import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { getDatabase, ref, get, set, remove } from "firebase/database";
import { app } from "./firebaseconfig";
import "./Inventory.css"; // Reuse the existing styles

const ExpiringSoonPage = () => {
  const [expiringProducts, setExpiringProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if a supermarket is logged in
    

    const fetchExpiringProducts = async () => {
      const db = getDatabase(app);
      const supermarketRef = ref(db,`qr_codes`);
      const snapshot = await get(supermarketRef);

      if (snapshot.exists()) {
        const productData = Object.entries(snapshot.val()).map(([key, product]) => {
          const expiryDate = new Date(product.expiry_date);
          const today = new Date();
          const daysToExpire = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));

          return {
            id: key, // Store product ID for future reference
            ...product,
            daysToExpire
          };
        });

        // Filter out expired products and those with more than 7 days left
        const expiringSoonProducts = productData.filter(product => product.daysToExpire > 0 && product.daysToExpire <= 7);

        setExpiringProducts(expiringSoonProducts);
      }
    };

    fetchExpiringProducts();
  }, [navigate]);

  // Function to move product to food bank
  const handleDonateToFoodBank = async (product) => {
    
    try {
      // Move product to food bank in Firebase
      const db = getDatabase(app);
      await set(ref(db, `qr_codes/food_bank/${product.id}`), product);
      
      // Remove product from the main product list
      await remove(ref(db, `qr_codes/products/${product.id}`));

      // Update state to remove the product from the list
      setExpiringProducts(prevProducts => prevProducts.filter(p => p.id !== product.id));

      alert(`${product.product_name} has been donated to the Food Bank!`);
    } catch (error) {
      console.error("Error donating product:", error);
      alert("Failed to donate product.");
    }
  };

  return (
    <div className="product-list-container">
      <h1>⚠️ Expiring Soon</h1>

      {expiringProducts.length === 0 ? (
        <p>No products expiring within a week.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Batch ID</th>
              <th>Manufacturer</th>
              <th>Manufacturing Date</th>
              <th>Expiry Date</th>
              <th>Days to Expire</th>
              <th>Total Units</th>
              <th>Action</th> {/* New Column for Food Bank Button */}
            </tr>
          </thead>
          <tbody>
            {expiringProducts.map((product) => (
              <tr key={product.id}>
                <td>{product.product_name}</td>
                <td>{product.batch_id}</td>
                <td>{product.manufacturer}</td>
                <td>{product.manufacturing_date}</td>
                <td>{product.expiry_date}</td>
                <td>{product.daysToExpire} days</td>
                <td>{product.total_units}</td>
                <td>
                  <button
                    className="btn btn-success"
                    onClick={() => handleDonateToFoodBank(product)}
                  >
                    🏛️ Food Bank
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* Back Button */}
      <Link to="/">
        <button className="btn btn-primary mt-3">🏠 Back to Dashboard</button>
      </Link>
    </div>
  );
};

export default ExpiringSoonPage;
