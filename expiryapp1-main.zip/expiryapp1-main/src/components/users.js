import { getAuth, createUserWithEmailAndPassword, sendPasswordResetEmail, fetchSignInMethodsForEmail } from "firebase/auth";
import { getDatabase, ref, set, get, remove } from "firebase/database";
import { app } from "./firebaseconfig";

const auth = getAuth();
const db = getDatabase(app);

/**
 * Fetches all users from the Firebase database.
 */
export const fetchUsers = async () => {
  const usersRef = ref(db, 'qr_codes/users');
  const snapshot = await get(usersRef);

  if (snapshot.exists()) {
    // We return an array of user objects here
    return Object.entries(snapshot.val()).map(([userId, userData]) => ({
      userId, ...userData
    }));
  }

  return [];
};




export const addUser = async (email, role) => {
  try {
    // Check if the email already exists in Firebase Authentication
    const signInMethods = await fetchSignInMethodsForEmail(auth, email);
    if (signInMethods.length > 0) {
      return { error: "This email is already in use." };
    }

    // Create user in Firebase Authentication
    const userCredential = await createUserWithEmailAndPassword(auth, email, "DefaultPassword123");
    const userId = userCredential.user.uid;

    // Save user in Firebase Database
    const userRef = ref(db, `qr_codes/users/${userId}`);
    await set(userRef, { email, role });

    // Send password reset email
    await sendPasswordResetEmail(auth, email);

    return { success: "User added successfully! Password reset email sent." };
  } catch (error) {
    return { error: error.message };
  }
};


/**
 * Removes a user from Firebase Database.
 */
export const removeUser = async (userId) => {
  const userRef = ref(db, `qr_codes/users/${userId}`);
  await remove(userRef);
  return { success: "User removed successfully!" };
};
