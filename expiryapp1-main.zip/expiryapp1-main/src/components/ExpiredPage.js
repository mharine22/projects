import React, { useEffect, useState } from "react";
import { getDatabase, ref, get, set } from "firebase/database";
import { app } from "./firebaseconfig";
import { getDiscount } from "./discount";
import { useNavigate } from "react-router-dom";
import "./Inventory.css"; // Reuse existing styles

const ExpiredProductsPage = () => {
  const [expiredProducts, setExpiredProducts] = useState([]);
  const [disposedProducts, setDisposedProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    
    const fetchProducts = async () => {
      try {
        const db = getDatabase(app);
        const productsRef = ref(db, `qr_codes`);
        const disposedRef = ref(db, `qr_codes/disposed_products`);
        
        const [productsSnapshot, disposedSnapshot] = await Promise.all([
          get(productsRef),
          get(disposedRef)
        ]);
        
        let expiredList = [];
        let disposedList = disposedSnapshot.exists() ? Object.values(disposedSnapshot.val()) : [];

        if (productsSnapshot.exists()) {
          const today = new Date();

          Object.values(productsSnapshot.val()).forEach((product) => {
            const discount = getDiscount(product.expiry_date, product.product_name);
            const expiryDate = new Date(product.expiry_date);
            const daysToExpire = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));

            if (discount === "Expired!") {
              expiredList.push({ ...product, discount, daysToExpire });
            }
          });
        }

        setExpiredProducts(expiredList);
        setDisposedProducts(disposedList);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchProducts();
  }, [navigate]);

  const disposeProduct = async (product) => {

    const db = getDatabase(app);
    const disposedRef = ref(db, `qr_codes/disposed_products/${product.batch_id}`);
    await set(disposedRef, product);

    setExpiredProducts(expiredProducts.filter(p => p.batch_id !== product.batch_id));
    setDisposedProducts([...disposedProducts, product]);
  };

  return (
    <div className="product-list-container">
      <h1>📛 Expired & Disposed Products</h1>

      <h2>🚨 Expired Products</h2>
      {expiredProducts.length === 0 ? (
        <p>No expired products found.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Batch ID</th>
              <th>Expiry Date</th>
              <th>Discount</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {expiredProducts.map((product, index) => (
              <tr key={index}>
                <td>{product.product_name}</td>
                <td>{product.batch_id}</td>
                <td>{product.expiry_date}</td>
                <td className="expired">❌ {product.discount}</td>
                <td>
                  <button className="btn btn-danger" onClick={() => disposeProduct(product)}>
                    Product Disposed
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {disposedProducts.length > 0 && (
        <div className="disposed-section">
          <h2>✅ Disposed Products</h2>
          <table>
            <thead>
              <tr>
                <th>Product Name</th>
                <th>Batch ID</th>
                <th>Expiry Date</th>
              </tr>
            </thead>
            <tbody>
              {disposedProducts.map((product, index) => (
                <tr key={index}>
                  <td>{product.product_name}</td>
                  <td>{product.batch_id}</td>
                  <td>{product.expiry_date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ExpiredProductsPage;