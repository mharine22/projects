import { useNavigate } from "react-router-dom";

const logoutUser = () => {
  localStorage.removeItem("user"); // ❌ Remove user session
  window.location.href = "/"; // 🔄 Redirect to Login page
};

export default logoutUser;
