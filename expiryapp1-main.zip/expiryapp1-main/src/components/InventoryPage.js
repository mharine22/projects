import React, { useState, useEffect } from "react";
import { getDatabase, ref, get } from "firebase/database";
import { app } from "./firebaseconfig";
import "./Inventory.css";

const ProductList = () => {
    const [products, setProducts] = useState([]);
    const [searchQuery, setSearchQuery] = useState("");
    const [manufacturerFilter, setManufacturerFilter] = useState("");
    const [sortBy, setSortBy] = useState("manufacturing_date");

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const db = getDatabase(app);
                const supermarketRef = ref(db, `qr_codes`);
                const snapshot = await get(supermarketRef);

                if (snapshot.exists()) {
                    const productData = Object.values(snapshot.val()).filter(
                        (item) => item && item.product_name // Ensure valid products
                    );
                    setProducts(productData);
                } else {
                    setProducts([]); // Set an empty array if no data is found
                }
            } catch (error) {
                console.error("Error fetching products:", error);
            }
        };
        fetchProducts();
    }, []);

    // Search & filter logic (ensuring product_name is defined)
    const filteredProducts = products
        .filter((product) => 
            product?.product_name?.toLowerCase().includes(searchQuery.toLowerCase())
        )
        .filter((product) => !manufacturerFilter || product?.manufacturer === manufacturerFilter)
        .sort((a, b) => new Date(a[sortBy]) - new Date(b[sortBy]));

    return (
        <div className="container">
            <h2 className="text-center my-4">📦 Product Inventory</h2>

            {/* Search & Filters */}
            <div className="row mb-3">
                <div className="col-md-4">
                    <input
                        type="text"
                        className="form-control"
                        placeholder="🔍 Search by product name"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>

                <div className="col-md-4">
                    <select className="form-control" onChange={(e) => setManufacturerFilter(e.target.value)}>
                        <option value="">🔹 All Manufacturers</option>
                        {[...new Set(products.map((p) => p.manufacturer))].map((manufacturer) => (
                            <option key={manufacturer} value={manufacturer}>{manufacturer}</option>
                        ))}
                    </select>
                </div>

                <div className="col-md-4">
                    <select className="form-control" onChange={(e) => setSortBy(e.target.value)}>
                        <option value="manufacturing_date">📅 Sort by Manufacturing Date</option>
                        <option value="expiry_date">⏳ Sort by Expiry Date</option>
                    </select>
                </div>
            </div>

            {/* Product Table */}
            <div className="table-responsive">
                <table className="table table-bordered table-hover">
                    <thead className="thead-dark">
                        <tr>
                            <th>📦 Product Name</th>
                            <th>🆔 Batch ID</th>
                            <th>🏭 Manufacturer</th>
                            <th>📅 Manufacturing Date</th>
                            <th>⏳ Expiry Date</th>
                            <th>🌡 Storage Conditions</th>
                            <th>🔢 Total Units</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredProducts.length > 0 ? (
                            filteredProducts.map((product, index) => (
                                <tr key={index}>
                                    <td>{product.product_name}</td>
                                    <td>{product.batch_id}</td>
                                    <td>{product.manufacturer}</td>
                                    <td>{product.manufacturing_date}</td>
                                    <td>{product.expiry_date}</td>
                                    <td>{product.storage_conditions}</td>
                                    <td>{product.total_units}</td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="7" className="text-center">🚫 No products found</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ProductList;
