
import { initializeApp } from "firebase/app";
import { getDatabase, ref, get, push, set, child } from "firebase/database";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "firebase/auth";
import { getFirestore, collection, doc, setDoc, getDoc } from "firebase/firestore";
import { getStorage, ref as sref, uploadBytes, getDownloadURL } from "firebase/storage";

// ✅ Firebase Configuration (Replace with actual credentials)
const firebaseConfig = {
  apiKey: "AIzaSyCY1lPG5uRnt2bw3wdrg7eGjz3mkoAw1lU",
  authDomain: "product-expiry-management.firebaseapp.com",
  databaseURL: "https://product-expiry-management-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "product-expiry-management",
  storageBucket: "product-expiry-management.appspot.com",
  messagingSenderId: "453668811856",
  appId: "1:453668811856:web:e9b1713218d616bc428d55",
  measurementId: "G-GVMBN8DDBJ"
};

// ✅ Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);
const auth = getAuth(app);
const firestore = getFirestore(app);
const storage = getStorage(app);

// ✅ **User Registration Function**
const registerUser = async (email, password, role) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Store user details in Firestore
    await setDoc(doc(firestore, "users", user.uid), {
      email,
      role,
    });

    console.log("✅ User Registered:", user.uid);
    return user;
  } catch (error) {
    console.error("❌ Registration Error:", error.message);
    throw error;
  }
};

// ✅ **User Login Function**
const loginUser = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // Fetch user data from Firestore
    const userDoc = await getDoc(doc(firestore, "users", user.uid));

    if (!userDoc.exists()) {
      throw new Error("User not found in Firestore");
    }

    const userData = userDoc.data();
    console.log("✅ User Logged In:", userData);

    return { ...userData, uid: user.uid };
  } catch (error) {
    console.error("❌ Login Error:", error.message);
    throw error;
  }
};

// ✅ **Logout Function**
const logoutUser = async () => {
  try {
    await signOut(auth);
    console.log("✅ Successfully Logged Out");
  } catch (error) {
    console.error("❌ Logout Failed:", error.message);
  }
};

// ✅ **Export Firebase Services and Functions**
export { 
  app, 
  database, 
  auth, 
  firestore, 
  storage, 
  ref, 
  get, 
  push, 
  set, 
  sref, 
  uploadBytes, 
  getDownloadURL, 
  registerUser, 
  loginUser, 
  logoutUser 
};
