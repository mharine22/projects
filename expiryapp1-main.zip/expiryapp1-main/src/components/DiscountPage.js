import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { getDiscount } from "./discount";
import { getDatabase, ref, get, set } from "firebase/database";
import { app } from "./firebaseconfig";
import "./Inventory.css"; 

const DiscountPage = () => {
  const [products, setProducts] = useState([]);
  const [discountedProducts, setDiscountedProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const db = getDatabase(app);

    const fetchProducts = async () => {
      try {
        const supermarketRef = ref(db, `qr_codes`);
        const discountedRef = ref(db, `qr_codes/discounted_products`);

        const [productsSnapshot, discountedSnapshot] = await Promise.all([
          get(supermarketRef),
          get(discountedRef),
        ]);

        let allProducts = [];
        let grantedDiscounts = [];

        if (productsSnapshot.exists()) {
          allProducts = Object.entries(productsSnapshot.val()).map(([key, product]) => ({
            id: key,
            ...product,
            discount: getDiscount(product.expiry_date, product.product_name),
          }));
        }

        if (discountedSnapshot.exists()) {
          grantedDiscounts = Object.entries(discountedSnapshot.val()).map(([key, product]) => ({
            id: key,
            ...product,
          }));
        }

        const filteredProducts = allProducts.filter(
          (product) => product.discount !== "Expired!" && product.discount !== "No Discount"
        );

        setProducts(filteredProducts);
        setDiscountedProducts(grantedDiscounts);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchProducts();
  }, []);

  const grantDiscount = async (product) => {
    const db = getDatabase(app);
    const discountedRef = ref(db, `qr_codes/discounted_products/${product.id}`);
    await set(discountedRef, product);

    setProducts(products.filter((p) => p.id !== product.id));
    setDiscountedProducts([...discountedProducts, product]);
  };

  return (
    <div className="product-list-container">
      <h1>📉 Discounted Products</h1>

      {products.length === 0 ? (
        <p>No discounted products available.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Batch ID</th>
              <th>Manufacturer</th>
              <th>Manufacturing Date</th>
              <th>Expiry Date</th>
              <th>Storage Conditions</th>
              <th>Total Units</th>
              <th>Discount</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id}>
                <td>{product.product_name}</td>
                <td>{product.batch_id}</td>
                <td>{product.manufacturer}</td>
                <td>{product.manufacturing_date}</td>
                <td>{product.expiry_date}</td>
                <td>{product.storage_conditions}</td>
                <td>{product.total_units}</td>
                <td className="discount">{product.discount}</td>
                <td>
                  <button className="btn btn-success" onClick={() => grantDiscount(product)}>Grant Discount</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {discountedProducts.length > 0 && (
        <div className="discounted-section">
          <h2>✅ Granted Discounts</h2>
          <table>
            <thead>
              <tr>
                <th>Product Name</th>
                <th>Batch ID</th>
                <th>Manufacturer</th>
                <th>Manufacturing Date</th>
                <th>Expiry Date</th>
                <th>Storage Conditions</th>
                <th>Total Units</th>
                <th>Discount</th>
              </tr>
            </thead>
            <tbody>
              {discountedProducts.map((product) => (
                <tr key={product.id}>
                  <td>{product.product_name}</td>
                  <td>{product.batch_id}</td>
                  <td>{product.manufacturer}</td>
                  <td>{product.manufacturing_date}</td>
                  <td>{product.expiry_date}</td>
                  <td>{product.storage_conditions}</td>
                  <td>{product.total_units}</td>
                  <td className="discount">{product.discount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Link to="/">
        <button className="btn btn-primary mt-3">🏠 Back to Dashboard</button>
      </Link>
    </div>
  );
};

export default DiscountPage;
