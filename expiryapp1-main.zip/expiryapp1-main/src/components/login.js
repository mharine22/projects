import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./login.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    // ✅ Hardcoded credentials
    const validEmail = "smdivyasundhari@gmail.com";
    const validPassword = "divya1234"; // 🔴 Change this to the actual password
   

    if (email === validEmail && password === validPassword) {
      navigate("/supermarketDashboard"); // 🚀 Redirect to dashboard
    } else {
      setError("❌ Invalid email or password.");
    }
  };

  return (
    <div className="login">
    <h2>🔑 Login</h2>
    <div className="login-container">
      
      <form onSubmit={handleLogin}>
        {error && <p className="error">{error}</p>}

        <label>Email:</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <label>Password:</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button type="submit">Login</button>
      </form>
    </div>
    </div>
  );
};

export default Login;
