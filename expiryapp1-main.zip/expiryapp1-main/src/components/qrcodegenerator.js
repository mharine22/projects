import React, { useState } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { useNavigate } from "react-router-dom";

const QRCodeGenerator = () => {
  const [batchData, setBatchData] = useState({
    batch_id: "",
    product_name: "",
    manufacturing_date: "",
    expiry_date: "",
    storage_conditions: "",
    manufacturer: "",
    total_units: "",
  });

  const [qrValue, setQrValue] = useState("");
  const navigate = useNavigate(); // Hook for navigation

  const handleChange = (e) => {
    setBatchData({ ...batchData, [e.target.name]: e.target.value });
  };

  const generateQRCode = () => {
    setQrValue(JSON.stringify({ ...batchData, timestamp: new Date().toISOString() }));
  };

  const downloadQR = () => {
    const canvas = document.getElementById("qrCode");
    if (!canvas) return;

    const pngUrl = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream");
    const link = document.createElement("a");
    link.href = pngUrl;
    link.download = "batch_qrcode.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="qr-container">
      <div className="card">
        <h2>QR Code Generator</h2>
        <div className="input-group">
          <input type="text" name="batch_id" placeholder="Batch ID" onChange={handleChange} />
          <input type="text" name="product_name" placeholder="Product Name" onChange={handleChange} />
          <input type="date" name="manufacturing_date" onChange={handleChange} />
          <input type="date" name="expiry_date" onChange={handleChange} />
          <input type="text" name="storage_conditions" placeholder="Storage Conditions" onChange={handleChange} />
          <input type="text" name="manufacturer" placeholder="Manufacturer" onChange={handleChange} />
          <input type="number" name="total_units" placeholder="Total Units" onChange={handleChange} />
        </div>
        <button className="btn-generate" onClick={generateQRCode}>Generate QR Code</button>

        {qrValue && (
          <div className="qr-section">
            <QRCodeCanvas id="qrCode" value={qrValue} size={256} level="L" />
            <button className="btn-download" onClick={downloadQR}>Download QR Code</button>
          </div>
        )}

        {/* Back to Home Button */}
        <button className="btn-home" onClick={() => navigate("/")}>Back to Home</button>
      </div>
    </div>
  );
};

export default QRCodeGenerator;