import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./supermarket.css";
import logoutUser from "./logout";

import { getAuth, onAuthStateChanged } from "firebase/auth";
import { getDatabase, ref, push } from "firebase/database";
import QRScanner from "./qrscanner";

const SupermarketDashboard = () => {
  const [user, setUser] = useState(null);
  const [showQRScanner, setShowQRScanner] = useState(false);
  const navigate = useNavigate(); // 🟢 Hook for navigation
  const auth = getAuth();
  useEffect(() => {
    const loggedInUser = localStorage.getItem("user");
    if (!loggedInUser) {
      navigate("/supermarketDashboard"); // 🔄 Redirect to login if not authenticated
    } else {
      setUser(loggedInUser);
    }
  }, [navigate]);

  // Function to handle QR code scan and add product to 'qr_codes' (without supermarket ID)
  const handleQRScan = (scannedData) => {
    const db = getDatabase();
    const qrCodesRef = ref(db, "qr_codes"); // No supermarket ID, directly to "qr_codes"

    push(qrCodesRef, scannedData)
      .then(() => {
        alert("Product added successfully!");
      })
      .catch((error) => {
        alert("Error adding product: " + error.message);
      });

    setShowQRScanner(false); // Close scanner after adding
  };

  return (
    <div className="con">
      <div className="navbar">TrackExpiry</div>
      <div className="container dashboard">
        <h2 className="heading">🏬 Supermarket Dashboard</h2>

        <div className="overview row">
          <button className="btn dashboard-btn col-md-4" onClick={() => setShowQRScanner(true)}>
            📷 ADD PRODUCTS
          </button>

          <button className="btn dashboard-btn col-md-4" onClick={() => navigate("/inventory")}>
            📦 VIEW INVENTORY
          </button>
          <button className="btn dashboard-btn col-md-4" onClick={() => navigate("/discounts")}>
            💲 DISCOUNTED PRODUCTS
          </button>
          <button className="btn dashboard-btn col-md-4" onClick={() => navigate("/expiring-soon")}>
            ⚠️ EXPIRING SOON
          </button>
          <button className="btn dashboard-btn col-md-4" onClick={() => navigate("/expired")}>
            🚨 EXPIRED PRODUCTS
          </button>

          <button className="btn logout-btn col-md-4" onClick={logoutUser}>
            🔴 LOGOUT
          </button>
        </div>

        {/* Show QR Scanner */}
        {showQRScanner && <QRScanner onScan={handleQRScan} onClose={() => setShowQRScanner(false)} />}
      </div>
    </div>
  );
};

export default SupermarketDashboard;
