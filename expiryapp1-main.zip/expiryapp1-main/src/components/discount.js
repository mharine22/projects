export function getDiscount(expiryDate, productName) {
    const today = new Date();
    const expiry = new Date(expiryDate);

    // Handle invalid date
    if (isNaN(expiry.getTime())) {
        console.error("Invalid expiry date:", expiryDate);
        return "No Discount";
    }

    // Calculate days left until expiry
    const diffTime = expiry - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    // Define product categories (Shelf Life Groups)
    const shortShelfLife = [
        "Milk", "Yogurt", "Meat", "Fish", "Bread", 
        "Fresh Fruits", "Fresh Vegetables", "Cream", "Salads", "Soft Cheese"
    ];
    
    const mediumShelfLife = [
        "Eggs", "Cheese", "Juice", "Cooked Meals", 
        "Butter", "Sauces", "Tofu", "Pickles", "Hummus", "Cold Cuts"
    ];
    
    const longShelfLife = [
        "Biscuit", "Canned Food", "Pasta", "Rice", "Chocolates", 
        "Dried Fruits", "Nuts", "Honey", "Instant Noodles", "Powdered Milk", "Flour", "Tea", "Coffee", "Sugar", "Oats"
    ];
    
    let discount = "No Discount";

    // 🟢 Short Shelf Life Products - Aggressive Discounts
    if (shortShelfLife.includes(productName)) {
        if (diffDays <= 0) {
            discount = "Expired!";
        } else if (diffDays <= 5) {
            discount = "70% Off";
        } else if (diffDays <= 10) {
            discount = "50% Off";
        } else if (diffDays <= 15) {
            discount = "30% Off";
        }

    // 🟡 Medium Shelf Life Products - Moderate Discounts
    } else if (mediumShelfLife.includes(productName)) {
        if (diffDays <= 0) {
            discount = "Expired!";
        } else if (diffDays <= 7) {
            discount = "60% Off";
        } else if (diffDays <= 14) {
            discount = "40% Off";
        } else if (diffDays <= 30) {
            discount = "20% Off";
        }

    // 🔵 Long Shelf Life Products - Early Discounts to Prevent Waste
    } else if (longShelfLife.includes(productName)) {
        if (diffDays <= 0) {
            discount = "Expired!";
        } else if (diffDays <= 14) {
            discount = "50% Off";  
        } else if (diffDays <= 30) {
            discount = "30% Off";
        } else if (diffDays <= 60) {
            discount = "10% Off";  
        }
    }

    console.log(`Discount for ${productName} (${expiryDate}): ${discount}`);
    return discount;
}
