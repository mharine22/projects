import React, { useState } from "react";
import BarcodeScannerComponent from "react-qr-barcode-scanner";
import { getDatabase, ref, get, update } from "firebase/database";
import { app } from "./firebaseconfig";
import { getDiscount } from "./discount"; // Function to apply discounts

const BillingPage = () => {
  const [scannedProducts, setScannedProducts] = useState([]);
  const [scanning, setScanning] = useState(false);
  const [barcode, setBarcode] = useState("");

  // Handle scanned barcode
  const handleScan = async (scannedBarcode) => {
    if (!scannedBarcode) return;
    setScanning(false); // Stop scanning once a barcode is detected

    const supermarketId = sessionStorage.getItem("supermarket_id");
    if (!supermarketId) {
      alert("You must be logged in.");
      return;
    }

    const db = getDatabase(app);
    const productRef = ref(db, `supermarkets/${supermarketId}/products/${scannedBarcode}`);
    const snapshot = await get(productRef);

    if (snapshot.exists()) {
      const product = snapshot.val();
      const discount = getDiscount(product.expiry_date, product.product_name);
      const priceAfterDiscount = product.price * (1 - parseFloat(discount) / 100);

      const newProduct = {
        id: scannedBarcode,
        name: product.product_name,
        price: product.price,
        discount: discount,
        finalPrice: priceAfterDiscount.toFixed(2),
        quantity: 1,
        totalPrice: priceAfterDiscount.toFixed(2),
      };

      setScannedProducts([...scannedProducts, newProduct]);
    } else {
      alert("Product not found.");
    }
  };

  // Update quantity and recalculate price
  const updateQuantity = (index, newQuantity) => {
    const updatedProducts = [...scannedProducts];
    updatedProducts[index].quantity = newQuantity;
    updatedProducts[index].totalPrice = (newQuantity * updatedProducts[index].finalPrice).toFixed(2);
    setScannedProducts(updatedProducts);
  };

  // Calculate total bill
  const getTotalBill = () => {
    return scannedProducts.reduce((sum, product) => sum + parseFloat(product.totalPrice), 0).toFixed(2);
  };

  // Confirm purchase and update Firebase
  const confirmPurchase = async () => {
    const db = getDatabase(app);
    const supermarketId = sessionStorage.getItem("supermarket_id");

    for (const product of scannedProducts) {
      const productRef = ref(db, `supermarkets/${supermarketId}/products/${product.id}`);
      const snapshot = await get(productRef);

      if (snapshot.exists()) {
        const currentProduct = snapshot.val();
        const newPurchasedQuantity = (currentProduct.purchased_quantity || 0) + product.quantity;
        const newTotalUnits = (currentProduct.total_units || 0) - newPurchasedQuantity;

        if (newTotalUnits < 0) {
          alert(`Not enough stock for ${product.name}`);
          return;
        }

        await update(productRef, {
          purchased_quantity: newPurchasedQuantity,
          total_units: newTotalUnits,
        });
      }
    }

    alert("Purchase successful!");
    setScannedProducts([]); // Clear cart
  };

  return (
    <div className="billing-container">
      <h1>🛒 Billing System</h1>

      {/* Barcode Scanner */}
      <button onClick={() => setScanning(true)}>📷 Scan Barcode</button>

      {scanning && (
        <div className="scanner-container">
          <BarcodeScannerComponent
            width={300}
            height={200}
            onUpdate={(err, result) => {
              if (result) {
                handleScan(result.text);
              }
            }}
          />
          <button onClick={() => setScanning(false)}>❌ Stop Scanning</button>
        </div>
      )}

      {/* Product List */}
      {scannedProducts.length > 0 && (
        <table>
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Price</th>
              <th>Discount</th>
              <th>Final Price</th>
              <th>Quantity</th>
              <th>Total Price</th>
            </tr>
          </thead>
          <tbody>
            {scannedProducts.map((product, index) => (
              <tr key={product.id}>
                <td>{product.name}</td>
                <td>₹{product.price}</td>
                <td>{product.discount}%</td>
                <td>₹{product.finalPrice}</td>
                <td>
                  <input
                    type="number"
                    min="1"
                    value={product.quantity}
                    onChange={(e) => updateQuantity(index, parseInt(e.target.value))}
                  />
                </td>
                <td>₹{product.totalPrice}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* Total Bill */}
      <h2>Total: ₹{getTotalBill()}</h2>
      <button onClick={confirmPurchase}>✅ Confirm & Generate Bill</button>
    </div>
  );
};

export default BillingPage;
