import React, { useState, useEffect, useRef } from "react";
import QrScanner from "qr-scanner";
import { database, ref, push } from "./firebaseconfig";

QrScanner.WORKER_PATH = process.env.PUBLIC_URL + "/qr-scanner-worker.min.js";

const QRScanner = ({ onClose }) => {
  const [scanning, setScanning] = useState(true);
  const [formData, setFormData] = useState({
    batch_id: "",
    product_name: "",
    manufacturing_date: "",
    expiry_date: "",
    manufacturer: "",
    total_units: "",
    storage_conditions: "",
    timestamp: new Date().toISOString(),
  });

  const videoRef = useRef(null);
  let scanner = useRef(null);

  useEffect(() => {
    if (videoRef.current && scanning) {
      scanner.current = new QrScanner(
        videoRef.current,
        (result) => {
          console.log("✅ QR Code Scanned:", result.data);
          setScanning(false);
          scanner.current.stop();

          try {
            const qrData = JSON.parse(result.data);
            setFormData((prevData) => ({
              ...prevData,
              ...qrData,
              timestamp: new Date().toISOString(),
            }));
          } catch (error) {
            console.error("❌ Invalid QR Code Data:", error);
            alert("Invalid QR Code. Please scan a valid one.");
            setScanning(true);
          }
        },
        { returnDetailedScanResult: true }
      );

      scanner.current.start();
    }

    return () => {
      if (scanner.current) scanner.current.stop();
    };
  }, [scanning]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // ✅ Store product in Firebase under "qr_codes"
      const dbRef = ref(database, "qr_codes");
      await push(dbRef, formData);
      alert("✅ Product Added Successfully!");
      setScanning(true);
    } catch (error) {
      console.error("❌ Error Submitting Data:", error);
      alert("Error submitting data. Try again.");
    }
  };

  return (
    <div className="fullscreen-container">
      <h2>QR Scanner</h2>
      {scanning && <video ref={videoRef} id="qr-video" className="fullscreen-video"></video>}

      {!scanning && (
        <form onSubmit={handleSubmit}>
          <label>Batch ID:</label>
          <input
            type="text"
            name="batch_id"
            value={formData.batch_id}
            onChange={(e) => setFormData({ ...formData, batch_id: e.target.value })}
            required
          />

          <label>Product Name:</label>
          <input
            type="text"
            name="product_name"
            value={formData.product_name}
            onChange={(e) => setFormData({ ...formData, product_name: e.target.value })}
            required
          />

          <label>Manufacturing Date:</label>
          <input
            type="date"
            name="manufacturing_date"
            value={formData.manufacturing_date}
            onChange={(e) => setFormData({ ...formData, manufacturing_date: e.target.value })}
            required
          />

          <label>Expiry Date:</label>
          <input
            type="date"
            name="expiry_date"
            value={formData.expiry_date}
            onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
            required
          />

          <label>Manufacturer:</label>
          <input
            type="text"
            name="manufacturer"
            value={formData.manufacturer}
            onChange={(e) => setFormData({ ...formData, manufacturer: e.target.value })}
            required
          />

          <label>Total Units:</label>
          <input
            type="number"
            name="total_units"
            value={formData.total_units}
            onChange={(e) => setFormData({ ...formData, total_units: e.target.value })}
            required
          />

          <label>Storage Conditions:</label>
          <input
            type="text"
            name="storage_conditions"
            value={formData.storage_conditions}
            onChange={(e) => setFormData({ ...formData, storage_conditions: e.target.value })}
            required
          />

          <button type="submit">Submit</button>
        </form>
      )}

      <button onClick={onClose}>❌ Close Scanner</button>
    </div>
  );
};

export default QRScanner;
