import logo from './logo.svg';
import './App.css';
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Supermarkets from "./components/supermarket";
import QRScanner from "./components/qrscanner";
import InventoryPage from './components/InventoryPage';
import Login from './components/login';

import DiscountPage from "./components/DiscountPage";
import ExpiredProductsPage from "./components/ExpiredPage";
import ExpiringSoonPage from "./components/ExpiringSoon";

import SupermarketDashboard from './components/supermarket';
import BillingPage from './components/barcode';

import QRCodeGenerator from './components/qrcodegenerator';


function App() {
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/scan-qr" element={<QRScanner />} />
          <Route path="/inventory" element={<InventoryPage />} />
          <Route path="/discounts" element={<DiscountPage />} />
          <Route path="/expired" element={<ExpiredProductsPage />} />
          <Route path="/expiring-soon" element={<ExpiringSoonPage />} />
          <Route path="/SupermarketDashboard" element={<SupermarketDashboard />} />
          <Route path="/login" element={<Login />} />
          <Route path="/barcode" element={<BillingPage />} />
          
          <Route path="/qrcodegenerator" element={<QRCodeGenerator/>} />
          
      
        </Routes>
            
      
      </div>
    </Router>
  );
}

export default App;
