const mysql = require('mysql2');
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs'); // added
const app = express();
const port = 3000;

// MySQL Connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'mysql@123',
    database: 'payroll'
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err.stack);
        return;
    }
    console.log('Connected to MySQL as ID:', connection.threadId);
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/images', express.static(path.join(__dirname, 'images')));

// Serve Login Page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Login Route
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = 'SELECT * FROM users WHERE username = ? AND password = ?';

    connection.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).send('Internal Server Error');
            return;
        }

        if (results.length > 0) {
            res.redirect('/home');
        } else {
            res.send('Invalid credentials');
        }
    });
});

// Serve Home Page
app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Add Employee
app.post('/addEmployee', (req, res) => {
    const { name, position, salary_without_deduction, tax_amount, total_salary, leave_days, hire_date } = req.body;
    const query = 'INSERT INTO employees (name, position, salary_without_deduction, tax_amount, total_salary, leave_days, hire_date) VALUES (?, ?, ?, ?, ?, ?, ?)';

    connection.query(query, [name, position, salary_without_deduction, tax_amount, total_salary, leave_days, hire_date], (err, results) => {
        if (err) {
            console.error('Error adding employee:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.redirect('/home');
    });
});

// View Employees
app.get('/viewEmployees', (req, res) => {
    const query = 'SELECT * FROM employees';

    connection.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching employees:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(results);
    });
});

// Update Employee
app.post('/updateEmployee', (req, res) => {
    const { id, name, position, salary_without_deduction, tax_amount, total_salary, leave_days, hire_date } = req.body;
    const query = 'UPDATE employees SET name = ?, position = ?, salary_without_deduction = ?, tax_amount = ?, total_salary = ?, leave_days = ?, hire_date = ? WHERE id = ?';

    connection.query(query, [name, position, salary_without_deduction, tax_amount, total_salary, leave_days, hire_date, id], (err, results) => {
        if (err) {
            console.error('Error updating employee:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.redirect('/home');
    });
});

// Delete Employee
app.post('/deleteEmployee', (req, res) => {
    const { id } = req.body;
    const query = 'DELETE FROM employees WHERE id = ?';

    connection.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error deleting employee:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.redirect('/home');
    });
});

// Route to handle form submission and generate the report
app.post('/report', (req, res) => {
    const position = req.body.position;
    const query = 'SELECT name FROM employees WHERE position = ?';

    connection.query(query, [position], (err, results) => {
        if (err) throw err;

        fs.readFile(path.join(__dirname, 'public', 'report.html'), 'utf8', (err, data) => {
            if (err) throw err;

            let reportHtml = data.replace(
                '<!-- Display report here -->',
                `<div>
                    <h2>${position.charAt(0).toUpperCase() + position.slice(1)} Report</h2>
                    <ul>${results.map(employee => `<li>${employee.name}</li>`).join('')}</ul>
                 </div>`
            );

            res.send(reportHtml);
        });
    });
});
// Endpoint to get recent employees
app.get('/recentEmployees', (req, res) => {
    const sql = 'SELECT name, position FROM employees ORDER BY hire_date DESC LIMIT 5'; // Adjust the query as per your table structure
    connection.query(sql, (err, result) => {
      if (err) {
        console.error('Error fetching recent employees:', err);
        res.status(500).json({ error: 'Error fetching recent employees' });
        return;
      }
      res.json(result);
    });
});

  
// Start server
app.listen(port, () => {
    console.log(`Server started on http://localhost:${port}`);
});
